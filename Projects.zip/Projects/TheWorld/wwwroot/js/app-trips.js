// app-trips.js
(function () {

    "use strict";

  // *** ORIGINAL ****
  // Creating the Module
  //angular.module("app-trips", ["simpleControls", "ngRoute"])
  //  .config(function ($routeProvider) {

  //    $routeProvider.when("/", {
  //      controller: "tripsController",
  //      controllerAs: "vm",
  //      templateUrl: "/views/tripsView.html"
  //    });

  //    $routeProvider.when("/editor/:tripName", {
  //      controller: "tripEditorController",
  //      controllerAs: "vm",
  //      templateUrl: "/views/tripEditorView.html"
  //    });

  //    $routeProvider.otherwise({ redirectTo: "/" });

  // *** MODIFIED ****
  // Creating the Module
  var appTrips = angular.module("app-trips", ["simpleControls", "ngRoute"]);

  appTrips.config(['$routeProvider', '$locationProvider',
        function ($routeProvider, $locationProvider) {

        //$provide.decorator('$sniffer', function ($delegate) {
        //    $delegate.history = false;
        //    return $delegate;
        //});

        //commenting out this line (switching to hashbang mode) breaks the app
        //-- unless # is added to the templates
        //$locationProvider
        //    .html5Mode(true)
        //    .hashPrefix('!');

        $routeProvider.when("/", {
            controller: "tripsController",
            controllerAs: "vm",
            templateUrl: "/views/tripsView.html"
        });

        $routeProvider.when("/editor/:tripName", {
            controller: "tripEditorController",
            controllerAs: "vm",
            templateUrl: "/views/tripEditorView.html"
        });

        $routeProvider.otherwise({ redirectTo: "/" });

        $locationProvider.html5Mode(false).hashPrefix('');   // This is very important line I added if we want to keep '#" in URL (i.e. in the template) Otherwise the URL is made of the extra /#%2F as a part of it.

    }]);

})();